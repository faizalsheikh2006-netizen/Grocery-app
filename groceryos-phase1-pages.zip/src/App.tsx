import { useEffect } from 'react'
import { Route, Routes } from 'react-router-dom'
import AppLayout from './components/layout/AppLayout'
import Dashboard from './pages/Dashboard'
import ComingSoon from './pages/ComingSoon'
import { NAV } from './config/nav'
import { requestPersistence } from './db/database'
export default function App() {
  useEffect(() => { void requestPersistence() }, [])
  return (<Routes><Route element={<AppLayout />}><Route index element={<Dashboard />} />
    {NAV.filter(n => n.to !== '/').map(n => <Route key={n.to} path={n.to} element={<ComingSoon />} />)}</Route></Routes>)
}
